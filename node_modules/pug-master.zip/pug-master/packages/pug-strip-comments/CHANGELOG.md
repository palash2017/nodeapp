# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## 1.0.1 - 2016-08-10
### Changed
- Project name is changed to Pug
- Otherwise unchanged from 1.0.0

## 1.0.0 - 2015-08-10
### Added
- Initial stable release – unchanged from 0.0.1

## 0.0.1 - 2015-08-10
### Added
- Initial release
