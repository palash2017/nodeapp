# Change log

## 1.2.4 / 2016-08-23

- Update to `pug-walk@1.0.0`

## 1.2.3 / 2016-07-18

- Fix includes using custom filters

## 1.2.2 / 2016-06-06

- Update to `jstransformer@1.0.0`

## 1.2.1 / 2016-04-27

- Apply filters to included files as well

## 1.2.0 / 2016-04-01

- Add support for specifying per-filter options

## 1.1.1 / 2015-12-23

- Update UglifyJS to 2.6.2
- Rename to Pug

## 1.1.0 / 2015-11-14

- Add support for filtered includes

## 1.0.0 / 2015-10-08

- Initial stable release
